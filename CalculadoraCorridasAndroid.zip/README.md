# Calculadora de Corridas (Android)

Projeto inicial Android nativo (Kotlin) para Xiaomi/Android. Interface escura, sem anúncios, sem mensalidade, configuração separada de carro e moto, cálculo manual e serviço de Acessibilidade experimental para ler texto visível em ofertas de apps de corrida.

## Importante: estado desta entrega
Este é o **código-fonte inicial**, não um APK compilado. O ambiente de criação não tem Android SDK/Gradle configurado para gerar e testar um APK assinado. Não instale APKs de terceiros que afirmem ser esta versão.

## O que já está implementado
- Interface escura em português.
- Escolha carro/moto.
- Campos para valor, distância até o passageiro, distância da viagem e duração.
- Configuração de consumo, combustível, custo adicional por km e meta de ganho por hora.
- Cálculo estimado de custo, lucro operacional, R$/km e R$/h.
- Atalho para as configurações de Acessibilidade e serviço que lê texto visível e tenta extrair preço/distância/duração.
- Não envia dados para servidores; sem anúncios e sem conta.

## Limitações da leitura automática
O Android AccessibilityService só consegue ler conteúdo que o aplicativo de origem expõe na árvore de acessibilidade. Apps podem ocultar dados, renderizar ofertas como imagem ou mudar a interface. A extração é experimental e pode preencher campos incorretamente. O app **não aceita, recusa, negocia nem clica em ofertas**. Confirme manualmente os valores antes de tomar decisões.

Acessibilidade é uma permissão poderosa. Ative o serviço somente se confiar no código que instalou. Xiaomi/HyperOS pode encerrar processos em segundo plano ou usar nomes de menu diferentes.

## Compilar em APK
Requer Android Studio recente, JDK 17 e Android SDK (compileSdk 35).
1. Abra a pasta do projeto no Android Studio.
2. Aguarde a sincronização Gradle.
3. Build > Build APK(s).
4. APK debug: `app/build/outputs/apk/debug/app-debug.apk`.

O projeto precisa de Gradle instalado/configurado pelo Android Studio. Este pacote não contém wrapper JAR nem APK pronto.

## Compilação automática pelo GitHub
O projeto inclui `.github/workflows/build-apk.yml`. Depois de enviar o conteúdo extraído para um repositório GitHub chamado `main`, abra a aba **Actions**, escolha **Gerar APK Android** e toque em **Run workflow**. Quando terminar com sucesso, abra a execução e baixe o artefato `CalculadoraCorridas-debug-apk`. O GitHub pode pedir que você habilite Actions para o repositório.
