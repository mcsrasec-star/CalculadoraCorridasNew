package br.com.calculadoracorridas

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.max

class MainActivity : Activity() {
    private val bg = Color.rgb(16,18,22)
    private val panel = Color.rgb(28,31,38)
    private val mint = Color.rgb(112,225,181)
    private val white = Color.rgb(241,243,247)
    private val muted = Color.rgb(164,171,183)
    private lateinit var amount: EditText
    private lateinit var pickupKm: EditText
    private lateinit var tripKm: EditText
    private lateinit var minutes: EditText
    private lateinit var consumption: EditText
    private lateinit var fuelPrice: EditText
    private lateinit var extraCost: EditText
    private lateinit var targetHour: EditText
    private lateinit var result: TextView
    private lateinit var vehicle: Spinner
    private lateinit var platform: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        if (!::amount.isInitialized) return
        val prefs = getSharedPreferences("offer_reader", MODE_PRIVATE)
        val detectedPrice = prefs.getString("price", null)
        val detectedKm = prefs.getString("distance", null)
        if (detectedPrice != null || detectedKm != null) {
            detectedPrice?.let { amount.setText(it) }
            detectedKm?.let { tripKm.setText(it) }
            result.text = "Sugestão lida da tela do outro app. Confira os valores antes de calcular."
            prefs.edit().remove("price").remove("distance").apply()
        }
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(label("CALCULADORA DE CORRIDAS", 22, mint, true))
        root.addView(label("Análise de oferta • offline • sem anúncios", 13, muted))
        root.addView(space(14))
        root.addView(cardTitle("Oferta da corrida"))
        platform = spinner(listOf("inDrive", "Uber", "99", "Outra"))
        root.addView(label("Aplicativo", 13, muted))
        root.addView(platform)
        vehicle = spinner(listOf("Carro", "Moto"))
        root.addView(label("Veículo", 13, muted))
        root.addView(vehicle)
        amount = field("Valor oferecido (R$)", "25,00")
        pickupKm = field("Distância até buscar passageiro (km)", "2")
        tripKm = field("Distância da viagem (km)", "10")
        minutes = field("Tempo total estimado (min)", "25")
        root.addView(amount); root.addView(pickupKm); root.addView(tripKm); root.addView(minutes)

        root.addView(space(12))
        root.addView(cardTitle("Custos do veículo"))
        consumption = field("Consumo médio (km/L)", "10")
        fuelPrice = field("Preço do combustível (R$/L)", "6,00")
        extraCost = field("Manutenção + pneus + depreciação (R$/km)", "0,20")
        targetHour = field("Meta de ganho bruto por hora (R$)", "35")
        root.addView(consumption); root.addView(fuelPrice); root.addView(extraCost); root.addView(targetHour)

        val calc = Button(this).apply {
            text = "CALCULAR RENTABILIDADE"
            setTextColor(Color.rgb(12,25,21))
            setBackgroundColor(mint)
            textSize = 15f
            setOnClickListener { calculate() }
        }
        root.addView(calc, lp(top=14, bottom=10))
        result = label("Preencha os dados e toque em calcular.", 15, white)
        result.setPadding(dp(14), dp(14), dp(14), dp(14))
        result.setBackgroundColor(panel)
        root.addView(result)

        root.addView(space(14))
        root.addView(cardTitle("Leitura automática (experimental)"))
        root.addView(label("Permite ao Android tentar ler o texto que o app de corrida expõe na tela. Não funciona em todas as ofertas; confira os dados antes de decidir.", 13, muted))
        val access = Button(this).apply {
            text = "CONFIGURAR LEITOR DE OFERTAS"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(access, lp(top=8))
        root.addView(label("Privacidade: os dados são processados localmente. O leitor não clica, não aceita e não recusa corridas.", 12, muted))
    }

    private fun calculate() {
        val price = num(amount)
        val pickup = num(pickupKm)
        val trip = num(tripKm)
        val mins = num(minutes)
        val kmL = num(consumption)
        val fuel = num(fuelPrice)
        val other = num(extraCost)
        val target = num(targetHour)
        if (price <= 0 || trip <= 0 || mins <= 0 || kmL <= 0 || fuel < 0 || pickup < 0 || other < 0) {
            result.text = "Confira os campos: valor, distância da viagem, tempo e consumo devem ser maiores que zero."
            return
        }
        val totalKm = pickup + trip
        val fuelCost = totalKm / kmL * fuel
        val maintenance = totalKm * other
        val costs = fuelCost + maintenance
        val profit = price - costs
        val perKm = price / totalKm
        val perHour = price / (mins / 60.0)
        val netHour = profit / (mins / 60.0)
        val verdict = when {
            profit <= 0 -> "NÃO COMPENSA: prejuízo estimado"
            perHour < target -> "ATENÇÃO: abaixo da sua meta por hora"
            else -> "POSSIVELMENTE BOA: confira trânsito e retorno vazio"
        }
        val nf = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
        result.text = "$verdict\n\n" +
            "Distância considerada: ${fmt(totalKm)} km\n" +
            "Valor bruto: ${nf.format(price)}\n" +
            "Combustível estimado: ${nf.format(fuelCost)}\n" +
            "Outros custos estimados: ${nf.format(maintenance)}\n" +
            "Sobra operacional estimada: ${nf.format(profit)}\n\n" +
            "Bruto por km: ${nf.format(perKm)}/km\n" +
            "Bruto por hora: ${nf.format(perHour)}/h\n" +
            "Sobra por hora: ${nf.format(netHour)}/h\n\n" +
            "Estimativa não inclui necessariamente taxas, pedágios, espera, cancelamento ou deslocamento após a corrida."
    }

    private fun num(e: EditText): Double {
        val s = e.text.toString().trim().replace("R$", "").replace(" ", "").replace(".", "").replace(",", ".")
        return s.toDoubleOrNull() ?: 0.0
    }
    private fun fmt(v: Double) = String.format(Locale("pt", "BR"), "%.2f", v)
    private fun field(hintText: String, initial: String): EditText {
        val box = EditText(this).apply {
            hint = hintText
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 15f
            setSingleLine(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(panel)
            setText(initial)
        }
        box.contentDescription = hintText
        return box
    }
    private fun spinner(items: List<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        setPadding(dp(8), dp(4), dp(8), dp(4))
    }
    private fun cardTitle(s: String) = label(s, 17, white, true).apply { setPadding(0, dp(6), 0, dp(6)) }
    private fun label(s: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
    }
    private fun space(h: Int) = View(this).apply { layoutParams = lp(top=h, bottom=h); minimumHeight = dp(h) }
    private fun lp(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply {
        topMargin = dp(top); bottomMargin = dp(bottom)
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
