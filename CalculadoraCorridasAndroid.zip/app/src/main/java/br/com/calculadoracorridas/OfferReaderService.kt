package br.com.calculadoracorridas

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.util.Log

/**
 * Leitor experimental: inspeciona texto que o app de origem já expõe à árvore
 * de acessibilidade. Não captura tela, não faz OCR e não interage com ofertas.
 */
class OfferReaderService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        try {
            val root = rootInActiveWindow ?: return
            val texts = ArrayList<String>()
            collect(root, texts, 0)
            if (texts.isNotEmpty()) {
                val joined = texts.distinct().joinToString(" | ")
                val priceMatch = Regex("""R\$\s?(\d+(?:[.,]\d{1,2})?)""").find(joined)
                val distanceMatch = Regex("""(\d+(?:[.,]\d{1,2})?)\s?km""", RegexOption.IGNORE_CASE).find(joined)
                if (priceMatch != null || distanceMatch != null) {
                    val prefs = getSharedPreferences("offer_reader", MODE_PRIVATE).edit()
                    priceMatch?.groupValues?.getOrNull(1)?.let { prefs.putString("price", it.replace(",", ".")) }
                    distanceMatch?.groupValues?.getOrNull(1)?.let { prefs.putString("distance", it.replace(",", ".")) }
                    prefs.apply()
                    Log.d("CorridasReader", "Sugestão de oferta salva localmente (${texts.size} textos lidos)")
                }
            }
        } catch (_: Exception) {
            // A interface de outros apps pode desaparecer durante a leitura.
        }
    }

    private fun collect(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 20 || out.size > 250) return
        node.text?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        node.contentDescription?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        for (i in 0 until node.childCount) collect(node.getChild(i), out, depth + 1)
    }

    override fun onInterrupt() {}
}
